import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getFeaturedProducts, getCategories } from "@/lib/data";

export default function HomePage() {
  const featured = getFeaturedProducts(6);
  const categories = getCategories();

  return (
    <div>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-20 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <div className="eyebrow mb-4">New season, slower living</div>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05] text-forest">
            Considered goods for a quieter home.
          </h1>
          <p className="mt-6 text-forest-400 text-lg max-w-md">
            Hand-finished ceramics, woven textiles and warm lighting from small
            studios — chosen for how they age, not just how they photograph.
          </p>
          <div className="mt-8 flex gap-4">
            <Link href="/products" className="btn-primary">
              Shop the collection
            </Link>
            <Link href="/products?category=Candles" className="btn-secondary">
              Explore candles
            </Link>
          </div>
        </div>
        <div className="relative aspect-square rounded-sm overflow-hidden bg-sand-100">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=1200"
            alt="A softly lit living room with ceramic vases and linen textiles"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* Category strip */}
      <section className="max-w-6xl mx-auto px-6 pb-16">
        <div className="flex flex-wrap gap-3">
          {categories.map((c) => (
            <Link
              key={c}
              href={`/products?category=${encodeURIComponent(c)}`}
              className="px-4 py-2 border border-forest-100 rounded-sm text-sm hover:border-brass hover:text-brass-600 transition-colors"
            >
              {c}
            </Link>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="eyebrow mb-2">Editor's picks</div>
            <h2 className="font-display text-3xl text-forest">Featured pieces</h2>
          </div>
          <Link href="/products" className="text-sm text-brass-600 hover:underline">
            View all products →
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Trust strip */}
      <section className="bg-forest text-sand-50">
        <div className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
          <div>
            <div className="font-display text-2xl mb-1">Secure checkout</div>
            <p className="text-sand-200 text-sm text-forest-100/80">
              Payments processed securely through Stripe.
            </p>
          </div>
          <div>
            <div className="font-display text-2xl mb-1">Small-batch makers</div>
            <p className="text-sm text-forest-100/80">
              Every product is sourced from independent studios.
            </p>
          </div>
          <div>
            <div className="font-display text-2xl mb-1">Easy returns</div>
            <p className="text-sm text-forest-100/80">
              30-day returns on all full-price items.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
