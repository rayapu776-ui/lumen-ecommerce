"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useCart } from "@/components/CartContext";

export default function CheckoutSuccessPage() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const { refresh } = useCart();
  const [status, setStatus] = useState("confirming");

  useEffect(() => {
    async function confirm() {
      if (!sessionId) return setStatus("error");
      const res = await fetch(`/api/checkout?session_id=${sessionId}`);
      if (res.ok) {
        setStatus("success");
        refresh();
      } else {
        setStatus("error");
      }
    }
    confirm();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  return (
    <div className="max-w-lg mx-auto px-6 py-24 text-center">
      {status === "confirming" && <p className="text-forest-400">Confirming your payment…</p>}
      {status === "success" && (
        <>
          <div className="text-5xl mb-4">✓</div>
          <h1 className="font-display text-3xl text-forest mb-3">Order confirmed</h1>
          <p className="text-forest-400 mb-8">
            Thank you — your payment went through and your order has been placed.
            You can track it from your account.
          </p>
          <Link href="/account/orders" className="btn-primary">
            View my orders
          </Link>
        </>
      )}
      {status === "error" && (
        <>
          <h1 className="font-display text-3xl text-forest mb-3">We couldn't confirm that</h1>
          <p className="text-forest-400 mb-8">
            If you completed payment, check your orders page — it may just need a
            moment to sync.
          </p>
          <Link href="/account/orders" className="btn-secondary">
            Check my orders
          </Link>
        </>
      )}
    </div>
  );
}
