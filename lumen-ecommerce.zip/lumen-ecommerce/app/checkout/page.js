"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/components/CartContext";
import { formatPrice } from "@/components/ProductCard";

export default function CheckoutPage() {
  const { items, subtotalCents, loading } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({ name: "", address: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 401) return router.push("/login");
        throw new Error(data.error || "Checkout failed");
      }
      window.location.href = data.url;
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  };

  if (loading) return <div className="max-w-4xl mx-auto px-6 py-16 text-forest-400">Loading…</div>;
  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-24 text-center text-forest-400">
        Your cart is empty.
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 grid md:grid-cols-2 gap-12">
      <div>
        <h1 className="font-display text-3xl text-forest mb-6">Shipping details</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm text-forest-400 mb-1 block">Full name</label>
            <input
              required
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm text-forest-400 mb-1 block">Shipping address</label>
            <textarea
              required
              rows={3}
              className="input"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />
          </div>
          {error && <p className="text-red-600 text-sm">{error}</p>}
          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? "Redirecting to Stripe…" : "Continue to payment"}
          </button>
          <p className="text-xs text-forest-400">
            You'll be redirected to Stripe's secure checkout. Use test card
            4242 4242 4242 4242, any future expiry, and any CVC.
          </p>
        </form>
      </div>

      <div>
        <h2 className="font-display text-2xl text-forest mb-6">Order summary</h2>
        <ul className="divide-y divide-forest-100 border-y border-forest-100 mb-4">
          {items.map((item) => (
            <li key={item.id} className="py-3 flex justify-between text-sm">
              <span>
                {item.name} × {item.quantity}
              </span>
              <span>{formatPrice(item.price_cents * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <div className="flex justify-between font-medium text-lg">
          <span>Total</span>
          <span>{formatPrice(subtotalCents)}</span>
        </div>
      </div>
    </div>
  );
}
