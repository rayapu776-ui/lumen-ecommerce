import { NextResponse } from "next/server";
import db from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

export async function PATCH(request, { params }) {
  const admin = requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });

  const p = await request.json();
  const existing = db.prepare("SELECT * FROM products WHERE id = ?").get(params.id);
  if (!existing) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  db.prepare(
    `UPDATE products SET
      name = @name, description = @description, price_cents = @price,
      compare_at_cents = @compareAt, category = @category, image_url = @image_url,
      stock = @stock, featured = @featured
     WHERE id = @id`
  ).run({
    id: params.id,
    name: p.name,
    description: p.description,
    price: p.price,
    compareAt: p.compareAt || null,
    category: p.category,
    image_url: p.image_url,
    stock: p.stock,
    featured: p.featured ? 1 : 0,
  });

  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(params.id);
  return NextResponse.json({ product });
}

export async function DELETE(_request, { params }) {
  const admin = requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });

  db.prepare("DELETE FROM products WHERE id = ?").run(params.id);
  return NextResponse.json({ ok: true });
}
