import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import db from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

const schema = z.object({
  name: z.string().min(1),
  description: z.string().optional().default(""),
  price: z.number().int().nonnegative(),
  compareAt: z.number().int().nonnegative().nullable().optional(),
  category: z.string().min(1),
  image_url: z.string().url(),
  stock: z.number().int().nonnegative(),
  featured: z.boolean().optional().default(false),
});

const slugify = (s) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export async function POST(request) {
  const admin = requireAdmin();
  if (!admin) return NextResponse.json({ error: "Admin access required." }, { status: 403 });

  const body = await request.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid product data." }, { status: 400 });
  }
  const p = parsed.data;

  const id = nanoid();
  let slug = slugify(p.name);
  const slugExists = db.prepare("SELECT id FROM products WHERE slug = ?").get(slug);
  if (slugExists) slug = `${slug}-${id.slice(0, 5)}`;

  db.prepare(
    `INSERT INTO products (id, name, slug, description, price_cents, compare_at_cents, category, image_url, stock, featured)
     VALUES (@id, @name, @slug, @description, @price, @compareAt, @category, @image_url, @stock, @featured)`
  ).run({
    id,
    slug,
    name: p.name,
    description: p.description,
    price: p.price,
    compareAt: p.compareAt || null,
    category: p.category,
    image_url: p.image_url,
    stock: p.stock,
    featured: p.featured ? 1 : 0,
  });

  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(id);
  return NextResponse.json({ product }, { status: 201 });
}
