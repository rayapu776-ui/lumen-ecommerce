import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import db from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getOrCreateCart, getCartItems } from "@/lib/data";
import { getStripe } from "@/lib/stripe";

// POST: build a Stripe Checkout Session from the user's cart and return its URL.
export async function POST(request) {
  const user = getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Please log in to check out." }, { status: 401 });
  }

  const { name, address } = await request.json();
  const cart = getOrCreateCart(user.id);
  const items = getCartItems(cart.id);

  if (items.length === 0) {
    return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  }

  const totalCents = items.reduce((sum, i) => sum + i.price_cents * i.quantity, 0);
  const orderId = nanoid();

  db.prepare(
    `INSERT INTO orders (id, user_id, status, total_cents, shipping_name, shipping_address)
     VALUES (?, ?, 'pending', ?, ?, ?)`
  ).run(orderId, user.id, totalCents, name, address);

  const insertItem = db.prepare(
    `INSERT INTO order_items (id, order_id, product_id, product_name, unit_price_cents, quantity)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  for (const item of items) {
    insertItem.run(nanoid(), orderId, item.product_id, item.name, item.price_cents, item.quantity);
  }

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || request.headers.get("origin");

  try {
    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: user.email,
      line_items: items.map((item) => ({
        price_data: {
          currency: "usd",
          product_data: { name: item.name },
          unit_amount: item.price_cents,
        },
        quantity: item.quantity,
      })),
      success_url: `${baseUrl}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/checkout`,
      metadata: { orderId, userId: user.id },
    });

    db.prepare("UPDATE orders SET stripe_session_id = ? WHERE id = ?").run(session.id, orderId);

    return NextResponse.json({ url: session.url });
  } catch (err) {
    db.prepare("UPDATE orders SET status = 'failed' WHERE id = ?").run(orderId);
    return NextResponse.json(
      { error: err.message || "Could not start checkout. Check your Stripe keys in .env.local." },
      { status: 500 }
    );
  }
}

// GET: called from the success page to confirm payment and finalize the order.
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get("session_id");
  if (!sessionId) {
    return NextResponse.json({ error: "Missing session_id" }, { status: 400 });
  }

  const stripe = getStripe();
  const session = await stripe.checkout.sessions.retrieve(sessionId);

  if (session.payment_status !== "paid") {
    return NextResponse.json({ error: "Payment not completed" }, { status: 400 });
  }

  const order = db.prepare("SELECT * FROM orders WHERE stripe_session_id = ?").get(sessionId);
  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  if (order.status !== "paid") {
    db.prepare("UPDATE orders SET status = 'paid' WHERE id = ?").run(order.id);

    // Decrement stock and clear the user's cart now that payment is confirmed.
    const orderItems = db.prepare("SELECT * FROM order_items WHERE order_id = ?").all(order.id);
    const decrementStock = db.prepare("UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?");
    for (const item of orderItems) {
      decrementStock.run(item.quantity, item.product_id);
    }

    const cart = getOrCreateCart(order.user_id);
    db.prepare("DELETE FROM cart_items WHERE cart_id = ?").run(cart.id);
  }

  return NextResponse.json({ ok: true, orderId: order.id });
}
