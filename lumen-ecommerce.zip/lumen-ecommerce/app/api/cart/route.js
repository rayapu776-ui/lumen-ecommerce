import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import db from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { getOrCreateCart, getCartItems } from "@/lib/data";

export async function GET() {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ items: [] });
  const cart = getOrCreateCart(user.id);
  const items = getCartItems(cart.id);
  return NextResponse.json({ items });
}

export async function POST(request) {
  const user = getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Please log in to add items to your cart." }, { status: 401 });
  }
  const { productId, quantity = 1 } = await request.json();
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(productId);
  if (!product) {
    return NextResponse.json({ error: "Product not found." }, { status: 404 });
  }

  const cart = getOrCreateCart(user.id);
  const existing = db
    .prepare("SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ?")
    .get(cart.id, productId);

  if (existing) {
    const newQty = Math.min(product.stock, existing.quantity + quantity);
    db.prepare("UPDATE cart_items SET quantity = ? WHERE id = ?").run(newQty, existing.id);
  } else {
    db.prepare(
      "INSERT INTO cart_items (id, cart_id, product_id, quantity) VALUES (?, ?, ?, ?)"
    ).run(nanoid(), cart.id, productId, Math.min(product.stock, quantity));
  }

  return NextResponse.json({ items: getCartItems(cart.id) });
}

export async function PATCH(request) {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { productId, quantity } = await request.json();
  const cart = getOrCreateCart(user.id);

  if (quantity <= 0) {
    db.prepare("DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?").run(cart.id, productId);
  } else {
    db.prepare(
      "UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?"
    ).run(quantity, cart.id, productId);
  }

  return NextResponse.json({ items: getCartItems(cart.id) });
}

export async function DELETE(request) {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const productId = searchParams.get("productId");
  const cart = getOrCreateCart(user.id);
  db.prepare("DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?").run(cart.id, productId);

  return NextResponse.json({ items: getCartItems(cart.id) });
}
