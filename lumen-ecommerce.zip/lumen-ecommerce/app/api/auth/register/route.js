import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import db from "@/lib/db";
import { hashPassword, signSession, setSessionCookie } from "@/lib/auth";

const schema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  password: z.string().min(6),
});

export async function POST(request) {
  const body = await request.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please fill in all fields correctly." }, { status: 400 });
  }
  const { name, email, password } = parsed.data;

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
  }

  const id = nanoid();
  const password_hash = await hashPassword(password);
  db.prepare(
    "INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, 'customer')"
  ).run(id, name, email, password_hash);

  const user = { id, name, email, role: "customer" };
  const token = signSession(user);
  setSessionCookie(token);

  return NextResponse.json({ user });
}
