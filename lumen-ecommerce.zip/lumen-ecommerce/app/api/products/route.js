import { NextResponse } from "next/server";
import { listProducts } from "@/lib/data";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q") || undefined;
  const category = searchParams.get("category") || undefined;
  const products = listProducts({ q, category });
  return NextResponse.json({ products });
}
