import { NextResponse } from "next/server";
import { getProductById } from "@/lib/data";

export async function GET(_request, { params }) {
  const product = getProductById(params.id);
  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }
  return NextResponse.json({ product });
}
