import { NextResponse } from "next/server";
import db from "@/lib/db";
import { getOrCreateCart } from "@/lib/data";
import { getStripe } from "@/lib/stripe";

// This webhook mirrors what a real production deployment would use instead
// of (or alongside) the client-driven confirmation in /api/checkout GET.
// Stripe calls this endpoint directly, so it works even if the customer
// closes their browser tab right after paying. To test it locally, run:
//   stripe listen --forward-to localhost:3000/api/webhook
export async function POST(request) {
  const body = await request.text();
  const signature = request.headers.get("stripe-signature");
  const stripe = getStripe();

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return NextResponse.json({ error: `Webhook signature verification failed` }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const order = db.prepare("SELECT * FROM orders WHERE stripe_session_id = ?").get(session.id);

    if (order && order.status !== "paid") {
      db.prepare("UPDATE orders SET status = 'paid' WHERE id = ?").run(order.id);

      const orderItems = db.prepare("SELECT * FROM order_items WHERE order_id = ?").all(order.id);
      const decrementStock = db.prepare("UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?");
      for (const item of orderItems) {
        decrementStock.run(item.quantity, item.product_id);
      }

      const cart = getOrCreateCart(order.user_id);
      db.prepare("DELETE FROM cart_items WHERE cart_id = ?").run(cart.id);
    }
  }

  return NextResponse.json({ received: true });
}
