import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getOrdersForUser } from "@/lib/data";
import { formatPrice } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default function OrdersPage() {
  const user = getCurrentUser();
  if (!user) redirect("/login");
  const orders = getOrdersForUser(user.id);

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl text-forest mb-2">Your orders</h1>
      <p className="text-forest-400 mb-8">Signed in as {user.email}</p>

      {orders.length === 0 ? (
        <p className="text-forest-400">You haven't placed any orders yet.</p>
      ) : (
        <ul className="space-y-6">
          {orders.map((order) => (
            <li key={order.id} className="border border-forest-100 rounded-sm p-5">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="text-sm text-forest-400">
                    Order #{order.id.slice(0, 8).toUpperCase()}
                  </div>
                  <div className="text-xs text-forest-400">
                    {new Date(order.created_at).toLocaleDateString()}
                  </div>
                </div>
                <span
                  className={`text-xs uppercase tracking-wide px-2 py-1 rounded-sm ${
                    order.status === "paid"
                      ? "bg-forest-100 text-forest-700"
                      : "bg-sand-100 text-forest-400"
                  }`}
                >
                  {order.status}
                </span>
              </div>
              <ul className="text-sm divide-y divide-forest-100">
                {order.items.map((item) => (
                  <li key={item.id} className="py-2 flex justify-between">
                    <span>
                      {item.product_name} × {item.quantity}
                    </span>
                    <span>{formatPrice(item.unit_price_cents * item.quantity)}</span>
                  </li>
                ))}
              </ul>
              <div className="flex justify-between mt-3 pt-3 border-t border-forest-100 font-medium">
                <span>Total</span>
                <span>{formatPrice(order.total_cents)}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
