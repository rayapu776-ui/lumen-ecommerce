"use client";

import Link from "next/link";
import { useCart } from "@/components/CartContext";
import { formatPrice } from "@/components/ProductCard";

export default function CartPage() {
  const { items, loading, subtotalCents, updateItem, removeItem } = useCart();

  if (loading) {
    return <div className="max-w-4xl mx-auto px-6 py-16 text-forest-400">Loading cart…</div>;
  }

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-24 text-center">
        <h1 className="font-display text-3xl text-forest mb-3">Your cart is empty</h1>
        <p className="text-forest-400 mb-8">
          Log in and add a few pieces you love — they'll show up here.
        </p>
        <Link href="/products" className="btn-primary">
          Browse products
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl text-forest mb-8">Your cart</h1>
      <ul className="divide-y divide-forest-100 border-y border-forest-100">
        {items.map((item) => (
          <li key={item.id} className="py-6 flex gap-4 items-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={item.image_url}
              alt={item.name}
              className="w-20 h-24 object-cover rounded-sm bg-sand-100"
            />
            <div className="flex-1">
              <Link href={`/products/${item.product_id}`} className="font-medium hover:text-brass-600">
                {item.name}
              </Link>
              <div className="text-forest-400 text-sm mt-1">
                {formatPrice(item.price_cents)} each
              </div>
              <button
                onClick={() => removeItem(item.product_id)}
                className="text-xs text-forest-400 hover:text-red-600 mt-2 underline"
              >
                Remove
              </button>
            </div>
            <div className="flex items-center border border-forest-100 rounded-sm">
              <button
                onClick={() => updateItem(item.product_id, Math.max(1, item.quantity - 1))}
                className="w-8 h-9 flex items-center justify-center hover:bg-sand-100"
              >
                −
              </button>
              <span className="w-8 text-center text-sm">{item.quantity}</span>
              <button
                onClick={() =>
                  updateItem(item.product_id, Math.min(item.stock, item.quantity + 1))
                }
                className="w-8 h-9 flex items-center justify-center hover:bg-sand-100"
              >
                +
              </button>
            </div>
            <div className="w-20 text-right font-medium">
              {formatPrice(item.price_cents * item.quantity)}
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-8 flex justify-end">
        <div className="w-full max-w-xs">
          <div className="flex justify-between text-forest-400 mb-2">
            <span>Subtotal</span>
            <span>{formatPrice(subtotalCents)}</span>
          </div>
          <div className="flex justify-between text-forest-400 mb-4 text-sm">
            <span>Shipping &amp; tax</span>
            <span>Calculated at checkout</span>
          </div>
          <Link href="/checkout" className="btn-primary w-full">
            Proceed to checkout
          </Link>
        </div>
      </div>
    </div>
  );
}
