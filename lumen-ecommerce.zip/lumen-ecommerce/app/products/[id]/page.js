import { getProductById, getReviewsForProduct } from "@/lib/data";
import { formatPrice } from "@/components/ProductCard";
import AddToCartBox from "@/components/AddToCartBox";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default function ProductDetailPage({ params }) {
  const product = getProductById(params.id);
  if (!product) notFound();
  const reviews = getReviewsForProduct(product.id);

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="grid md:grid-cols-2 gap-12">
        <div className="aspect-[4/5] bg-sand-100 rounded-sm overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <div className="eyebrow mb-2">{product.category}</div>
          <h1 className="font-display text-4xl text-forest">{product.name}</h1>
          <div className="mt-3 flex items-center gap-2 text-sm text-forest-400">
            <span>★ {product.rating.toFixed(1)}</span>
            <span>·</span>
            <span>{reviews.length} reviews</span>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl text-forest-600 font-medium">
              {formatPrice(product.price_cents)}
            </span>
            {product.compare_at_cents && (
              <span className="text-forest-400 line-through">
                {formatPrice(product.compare_at_cents)}
              </span>
            )}
          </div>
          <p className="mt-6 text-forest-400 leading-relaxed">{product.description}</p>

          <AddToCartBox product={product} />
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-20 max-w-2xl">
        <h2 className="font-display text-2xl text-forest mb-6">Customer reviews</h2>
        {reviews.length === 0 ? (
          <p className="text-forest-400">No reviews yet — be the first to leave one after purchase.</p>
        ) : (
          <ul className="space-y-6">
            {reviews.map((r) => (
              <li key={r.id} className="border-b border-forest-100 pb-6">
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-medium">{r.user_name}</span>
                  <span className="text-brass">{"★".repeat(r.rating)}</span>
                </div>
                {r.comment && <p className="mt-2 text-forest-400">{r.comment}</p>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
