import ProductCard from "@/components/ProductCard";
import { listProducts, getCategories } from "@/lib/data";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function ProductsPage({ searchParams }) {
  const { q, category } = searchParams;
  const products = listProducts({ q, category });
  const categories = getCategories();

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="mb-8">
        <div className="eyebrow mb-2">Shop</div>
        <h1 className="font-display text-4xl text-forest">
          {category ? category : q ? `Results for “${q}”` : "All products"}
        </h1>
        <p className="text-forest-400 mt-2">{products.length} products</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-10">
        <Link
          href="/products"
          className={`px-3 py-1.5 text-sm rounded-sm border ${
            !category ? "bg-forest text-white border-forest" : "border-forest-100"
          }`}
        >
          All
        </Link>
        {categories.map((c) => (
          <Link
            key={c}
            href={`/products?category=${encodeURIComponent(c)}`}
            className={`px-3 py-1.5 text-sm rounded-sm border ${
              category === c ? "bg-forest text-white border-forest" : "border-forest-100"
            }`}
          >
            {c}
          </Link>
        ))}
      </div>

      {products.length === 0 ? (
        <div className="text-center py-24 text-forest-400">
          No products match your search. Try a different term or browse all products.
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-10">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
