import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { getAllOrders } from "@/lib/data";
import { formatPrice } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default function AdminOrdersPage() {
  const admin = requireAdmin();
  if (!admin) redirect("/login");
  const orders = getAllOrders();

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <h1 className="font-display text-3xl text-forest mb-8">Admin · Orders</h1>
      {orders.length === 0 ? (
        <p className="text-forest-400">No orders placed yet.</p>
      ) : (
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="text-left border-b border-forest-100 text-forest-400">
              <th className="py-3 pr-4">Order</th>
              <th className="py-3 pr-4">Customer</th>
              <th className="py-3 pr-4">Items</th>
              <th className="py-3 pr-4">Total</th>
              <th className="py-3 pr-4">Status</th>
              <th className="py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-b border-forest-100">
                <td className="py-3 pr-4 font-mono text-xs">{o.id.slice(0, 8)}</td>
                <td className="py-3 pr-4">
                  {o.customer_name}
                  <div className="text-xs text-forest-400">{o.customer_email}</div>
                </td>
                <td className="py-3 pr-4">{o.items.length}</td>
                <td className="py-3 pr-4">{formatPrice(o.total_cents)}</td>
                <td className="py-3 pr-4">
                  <span
                    className={`text-xs uppercase px-2 py-1 rounded-sm ${
                      o.status === "paid"
                        ? "bg-forest-100 text-forest-700"
                        : "bg-sand-100 text-forest-400"
                    }`}
                  >
                    {o.status}
                  </span>
                </td>
                <td className="py-3 text-forest-400">
                  {new Date(o.created_at).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
