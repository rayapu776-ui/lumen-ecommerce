import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { listProducts } from "@/lib/data";
import AdminProductManager from "@/components/AdminProductManager";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function AdminProductsPage() {
  const admin = requireAdmin();
  if (!admin) redirect("/login");
  const products = listProducts();

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-3xl text-forest">Admin · Products</h1>
        <Link href="/admin/orders" className="text-sm text-brass-600 underline">
          View all orders →
        </Link>
      </div>
      <AdminProductManager initialProducts={products} />
    </div>
  );
}
