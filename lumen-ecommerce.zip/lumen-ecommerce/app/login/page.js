"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) return setError(data.error || "Login failed");
    router.push("/");
    router.refresh();
  };

  return (
    <div className="max-w-sm mx-auto px-6 py-20">
      <h1 className="font-display text-3xl text-forest mb-2">Welcome back</h1>
      <p className="text-forest-400 mb-8 text-sm">Log in to view your orders and cart.</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          required
          type="email"
          placeholder="Email"
          className="input"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          required
          type="password"
          placeholder="Password"
          className="input"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button type="submit" disabled={submitting} className="btn-primary w-full">
          {submitting ? "Logging in…" : "Log in"}
        </button>
      </form>
      <p className="text-sm text-forest-400 mt-6">
        No account?{" "}
        <Link href="/register" className="text-brass-600 underline">
          Create one
        </Link>
      </p>
      <div className="mt-8 p-4 bg-sand-100 rounded-sm text-xs text-forest-400 leading-relaxed">
        <strong>Demo accounts</strong>
        <br />
        Admin — admin@lumen.dev / admin123
        <br />
        Customer — demo@lumen.dev / demo1234
      </div>
    </div>
  );
}
