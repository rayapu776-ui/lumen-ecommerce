/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#20241f",
        forest: {
          DEFAULT: "#2f3e2e",
          50: "#f3f5f2",
          100: "#e2e8e0",
          400: "#5c7359",
          600: "#2f3e2e",
          700: "#232f22",
          900: "#161f15",
        },
        sand: {
          50: "#faf8f3",
          100: "#f3efe4",
          200: "#e9e2d1",
        },
        brass: {
          DEFAULT: "#b08d57",
          400: "#c4a473",
          600: "#96733f",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      borderRadius: {
        sm: "2px",
      },
    },
  },
  plugins: [],
};
