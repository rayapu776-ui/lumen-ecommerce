// scripts/seed.js
// Populates the SQLite database with demo products and two demo accounts
// (an admin and a regular customer) so the app is immediately explorable.
// Run with: npm run seed

const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");
const { nanoid } = require("nanoid");

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "lumen.db"));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
  description TEXT, price_cents INTEGER NOT NULL, compare_at_cents INTEGER,
  category TEXT NOT NULL, image_url TEXT NOT NULL, stock INTEGER NOT NULL DEFAULT 0,
  rating REAL NOT NULL DEFAULT 4.5, featured INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS carts (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS cart_items (
  id TEXT PRIMARY KEY, cart_id TEXT NOT NULL, product_id TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1, UNIQUE(cart_id, product_id)
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
  total_cents INTEGER NOT NULL, stripe_session_id TEXT, shipping_name TEXT,
  shipping_address TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY, order_id TEXT NOT NULL, product_id TEXT NOT NULL,
  product_name TEXT NOT NULL, unit_price_cents INTEGER NOT NULL, quantity INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY, product_id TEXT NOT NULL, user_id TEXT NOT NULL,
  rating INTEGER NOT NULL, comment TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

const products = [
  {
    name: "Amber Pillar Candle",
    category: "Candles",
    price: 2400,
    compareAt: 2900,
    desc: "Hand-poured soy wax candle with notes of amber, sandalwood and dried fig. 60-hour burn time.",
    image: "https://images.unsplash.com/photo-1602874801007-bd36c39c33c9?w=800",
    stock: 42,
    rating: 4.8,
    featured: 1,
  },
  {
    name: "Stoneware Coffee Mug",
    category: "Ceramics",
    price: 1800,
    compareAt: null,
    desc: "Matte-glazed stoneware mug, wheel-thrown and kiln-fired individually. Holds 350ml.",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=800",
    stock: 65,
    rating: 4.6,
    featured: 1,
  },
  {
    name: "Linen Throw Blanket",
    category: "Textiles",
    price: 6900,
    compareAt: 7900,
    desc: "Pre-washed 100% European linen throw, woven in a soft herringbone pattern. 130x180cm.",
    image: "https://images.unsplash.com/photo-1600166898405-da9535204843?w=800",
    stock: 24,
    rating: 4.9,
    featured: 1,
  },
  {
    name: "Oak Wall Shelf",
    category: "Furniture",
    price: 5200,
    compareAt: null,
    desc: "Solid oak floating shelf with a hidden mounting bracket. 60cm wide, holds up to 15kg.",
    image: "https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?w=800",
    stock: 18,
    rating: 4.7,
    featured: 0,
  },
  {
    name: "Ceramic Table Lamp",
    category: "Lighting",
    price: 8900,
    compareAt: 9900,
    desc: "Textured ceramic base with a hand-stitched linen shade. Warm 2700K bulb included.",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800",
    stock: 12,
    rating: 4.5,
    featured: 1,
  },
  {
    name: "Woven Storage Basket",
    category: "Storage",
    price: 3400,
    compareAt: null,
    desc: "Hand-woven seagrass basket with leather handles. Great for blankets, plants or laundry.",
    image: "https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800",
    stock: 30,
    rating: 4.4,
    featured: 0,
  },
  {
    name: "Marble Coasters (Set of 4)",
    category: "Tableware",
    price: 2200,
    compareAt: null,
    desc: "Polished marble coasters with a cork underside to protect surfaces. Set of four.",
    image: "https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800",
    stock: 55,
    rating: 4.6,
    featured: 0,
  },
  {
    name: "Brass Drawer Pulls (Pair)",
    category: "Hardware",
    price: 1600,
    compareAt: 1900,
    desc: "Solid brass drawer pulls with an aged patina finish. Sold as a pair with fixings.",
    image: "https://images.unsplash.com/photo-1622560481156-01ac9c2b4c8c?w=800",
    stock: 80,
    rating: 4.3,
    featured: 0,
  },
  {
    name: "Cotton Bath Towel Set",
    category: "Textiles",
    price: 4200,
    compareAt: null,
    desc: "Set of two combed-cotton bath towels, 600gsm, in a heathered stone colourway.",
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800",
    stock: 38,
    rating: 4.7,
    featured: 0,
  },
  {
    name: "Terrazzo Planter",
    category: "Ceramics",
    price: 2900,
    compareAt: null,
    desc: "Speckled terrazzo-effect concrete planter with drainage hole and matching saucer.",
    image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800",
    stock: 27,
    rating: 4.5,
    featured: 1,
  },
  {
    name: "Walnut Cutting Board",
    category: "Kitchen",
    price: 3800,
    compareAt: 4400,
    desc: "End-grain walnut cutting board, finished with food-safe mineral oil. 35x25cm.",
    image: "https://images.unsplash.com/photo-1594736797933-d0501ba2fe65?w=800",
    stock: 20,
    rating: 4.8,
    featured: 0,
  },
  {
    name: "Recycled Glass Vase",
    category: "Decor",
    price: 2600,
    compareAt: null,
    desc: "Hand-blown vase made from recycled glass with a soft sea-green tint. 25cm tall.",
    image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=800",
    stock: 33,
    rating: 4.6,
    featured: 0,
  },
];

const slugify = (s) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const insertProduct = db.prepare(`
  INSERT OR IGNORE INTO products
  (id, name, slug, description, price_cents, compare_at_cents, category, image_url, stock, rating, featured)
  VALUES (@id, @name, @slug, @description, @price, @compareAt, @category, @image, @stock, @rating, @featured)
`);

const insertMany = db.transaction((rows) => {
  for (const p of rows) {
    insertProduct.run({
      id: nanoid(),
      name: p.name,
      slug: slugify(p.name),
      description: p.desc,
      price: p.price,
      compareAt: p.compareAt,
      category: p.category,
      image: p.image,
      stock: p.stock,
      rating: p.rating,
      featured: p.featured,
    });
  }
});
insertMany(products);

const insertUser = db.prepare(`
  INSERT OR IGNORE INTO users (id, name, email, password_hash, role)
  VALUES (@id, @name, @email, @hash, @role)
`);

const demoAccounts = [
  { name: "Admin User", email: "admin@lumen.dev", password: "admin123", role: "admin" },
  { name: "Demo Customer", email: "demo@lumen.dev", password: "demo1234", role: "customer" },
];

for (const acc of demoAccounts) {
  insertUser.run({
    id: nanoid(),
    name: acc.name,
    email: acc.email,
    hash: bcrypt.hashSync(acc.password, 10),
    role: acc.role,
  });
}

console.log("✅ Seed complete.");
console.log(`   ${products.length} products inserted.`);
console.log("   Demo accounts:");
console.log("     admin@lumen.dev / admin123  (admin)");
console.log("     demo@lumen.dev  / demo1234  (customer)");
