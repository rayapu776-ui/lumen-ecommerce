# LUMEN — Full-Stack E-Commerce Platform

A complete e-commerce web application built with **Next.js 14 (App Router)**, featuring authentication, a shopping cart, **real Stripe payment integration**, order history, and an admin dashboard for managing products and orders.

Built as a second-year academic project — designed to be portfolio-ready for GitHub and LinkedIn.

![Tech](https://img.shields.io/badge/Next.js-14-black) ![Tech](https://img.shields.io/badge/React-18-blue) ![Tech](https://img.shields.io/badge/Stripe-Payments-635BFF) ![Tech](https://img.shields.io/badge/SQLite-Database-07405e) ![Tech](https://img.shields.io/badge/TailwindCSS-Styling-38bdf8)

---

## ✨ Features

**Storefront**
- Product catalog with category filters and live search
- Product detail pages with stock status and customer reviews
- Responsive, custom-designed UI (Tailwind CSS, Fraunces + Inter typefaces)

**Cart & Checkout**
- Persistent server-side cart per logged-in user
- Quantity controls, line-item removal, live subtotal
- **Real Stripe Checkout integration** (test mode) — redirect to Stripe's hosted payment page
- Order confirmation flow + Stripe webhook endpoint (production-style async confirmation)
- Automatic stock deduction and cart clearing after a successful payment

**Accounts**
- Email/password registration and login
- Passwords hashed with bcrypt, sessions signed with JWT in an httpOnly cookie
- Order history page for each customer

**Admin Dashboard**
- Role-protected `/admin` routes (admin vs. customer)
- Full CRUD for products (add, edit, delete, feature on homepage)
- Orders overview across all customers

**Engineering**
- Next.js App Router with server components + API routes
- SQLite database (via `better-sqlite3`) — zero external services, runs anywhere
- Input validation with Zod
- Clean data-access layer (`lib/data.js`) separating queries from routes

---

## 🧱 Tech Stack

| Layer          | Technology                          |
|----------------|--------------------------------------|
| Frontend       | Next.js 14, React 18, Tailwind CSS   |
| Backend        | Next.js API routes (Node.js)         |
| Database       | SQLite (`better-sqlite3`)            |
| Auth           | JWT + bcrypt, httpOnly cookies       |
| Payments       | Stripe Checkout                      |
| Validation     | Zod                                  |

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js 18+ installed
- A free [Stripe account](https://dashboard.stripe.com/register) (for test API keys)

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment variables
```bash
cp .env.example .env.local
```
Then open `.env.local` and fill in:
- `JWT_SECRET` — any long random string
- `STRIPE_SECRET_KEY` and `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` — from your [Stripe test API keys](https://dashboard.stripe.com/test/apikeys)

### 4. Seed the database
This creates `data/lumen.db` with 12 sample products and two demo accounts:
```bash
npm run seed
```

### 5. Run the app
```bash
npm run dev
```
Visit **http://localhost:3000**

### Demo accounts
| Role     | Email              | Password  |
|----------|---------------------|-----------|
| Admin    | admin@lumen.dev      | admin123  |
| Customer | demo@lumen.dev       | demo1234  |

### Test payments
Use Stripe's test card at checkout:
```
Card number: 4242 4242 4242 4242
Expiry: any future date
CVC: any 3 digits
```

---

## 📁 Project Structure

```
lumen-ecommerce/
├── app/
│   ├── api/              # REST API routes (auth, cart, checkout, admin, webhook)
│   ├── products/          # Product listing + detail pages
│   ├── cart/               # Cart page
│   ├── checkout/          # Checkout + Stripe success page
│   ├── login/ register/   # Auth pages
│   ├── account/orders/   # Customer order history
│   ├── admin/              # Admin product & order management
│   └── layout.js, page.js
├── components/            # Reusable React components
├── lib/                    # Database, auth, Stripe helpers
├── scripts/seed.js        # Database seeding script
└── data/lumen.db          # SQLite database (created after seeding)
```

---

## 🔭 Possible Extensions

- Wishlist / saved items
- Product image galleries and variants (size/color)
- Coupon codes and discounts
- Email receipts (e.g. via Resend or Nodemailer)
- Deploy to Vercel + swap SQLite for hosted Postgres (e.g. Neon or Supabase)

---

## 📄 License

This project is open source and available for learning purposes under the MIT License.
