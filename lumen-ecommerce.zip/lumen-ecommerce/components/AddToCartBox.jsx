"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "./CartContext";

export default function AddToCartBox({ product }) {
  const { addItem } = useCart();
  const router = useRouter();
  const [qty, setQty] = useState(1);
  const [status, setStatus] = useState("idle");

  const handleAdd = async () => {
    setStatus("loading");
    const res = await addItem(product.id, qty);
    if (res.ok) {
      setStatus("added");
      setTimeout(() => setStatus("idle"), 1500);
    } else {
      setStatus("idle");
      const data = await res.json().catch(() => ({}));
      alert(data.error || "Could not add to cart. Please log in first.");
      if (res.status === 401) router.push("/login");
    }
  };

  return (
    <div className="mt-6">
      <div className="flex items-center gap-4">
        <div className="flex items-center border border-forest-100 rounded-sm">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="w-9 h-10 flex items-center justify-center hover:bg-sand-100"
          >
            −
          </button>
          <span className="w-10 text-center">{qty}</span>
          <button
            onClick={() => setQty((q) => Math.min(product.stock, q + 1))}
            className="w-9 h-10 flex items-center justify-center hover:bg-sand-100"
          >
            +
          </button>
        </div>
        <button
          onClick={handleAdd}
          disabled={status === "loading" || product.stock === 0}
          className="btn-primary flex-1"
        >
          {product.stock === 0
            ? "Out of stock"
            : status === "added"
            ? "Added to cart ✓"
            : status === "loading"
            ? "Adding…"
            : "Add to cart"}
        </button>
      </div>
      <p className="text-xs text-forest-400 mt-3">
        {product.stock > 0 ? `${product.stock} in stock` : "Currently unavailable"}
      </p>
    </div>
  );
}
