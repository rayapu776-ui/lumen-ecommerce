export default function Footer() {
  return (
    <footer className="border-t border-forest-100 mt-24">
      <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div className="col-span-2 md:col-span-1">
          <div className="font-display text-xl text-forest mb-3">LUMEN</div>
          <p className="text-forest-400">
            Considered goods for a slower home. Ceramics, textiles and lighting
            made by small studios.
          </p>
        </div>
        <div>
          <div className="eyebrow mb-3">Shop</div>
          <ul className="space-y-2 text-forest-400">
            <li>Candles</li>
            <li>Ceramics</li>
            <li>Textiles</li>
            <li>Lighting</li>
          </ul>
        </div>
        <div>
          <div className="eyebrow mb-3">Support</div>
          <ul className="space-y-2 text-forest-400">
            <li>Shipping</li>
            <li>Returns</li>
            <li>Contact</li>
          </ul>
        </div>
        <div>
          <div className="eyebrow mb-3">Project</div>
          <ul className="space-y-2 text-forest-400">
            <li>Built with Next.js</li>
            <li>Stripe test payments</li>
            <li>SQLite database</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-forest-100 py-6 text-center text-xs text-forest-400">
        © {new Date().getFullYear()} LUMEN — a student e-commerce project.
      </div>
    </footer>
  );
}
