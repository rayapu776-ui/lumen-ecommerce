"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatPrice } from "./ProductCard";

const emptyForm = {
  name: "",
  description: "",
  price: "",
  compareAt: "",
  category: "",
  image_url: "",
  stock: "",
  featured: false,
};

export default function AdminProductManager({ initialProducts }) {
  const router = useRouter();
  const [products, setProducts] = useState(initialProducts);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
  };

  const startEdit = (p) => {
    setEditingId(p.id);
    setForm({
      name: p.name,
      description: p.description || "",
      price: (p.price_cents / 100).toString(),
      compareAt: p.compare_at_cents ? (p.compare_at_cents / 100).toString() : "",
      category: p.category,
      image_url: p.image_url,
      stock: p.stock.toString(),
      featured: !!p.featured,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const payload = {
      name: form.name,
      description: form.description,
      price: Math.round(parseFloat(form.price) * 100),
      compareAt: form.compareAt ? Math.round(parseFloat(form.compareAt) * 100) : null,
      category: form.category,
      image_url: form.image_url,
      stock: parseInt(form.stock, 10),
      featured: form.featured,
    };
    const url = editingId ? `/api/admin/products/${editingId}` : "/api/admin/products";
    const method = editingId ? "PATCH" : "POST";
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) return setError(data.error || "Something went wrong");

    if (editingId) {
      setProducts((prev) => prev.map((p) => (p.id === editingId ? data.product : p)));
    } else {
      setProducts((prev) => [data.product, ...prev]);
    }
    resetForm();
    router.refresh();
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    if (res.ok) {
      setProducts((prev) => prev.filter((p) => p.id !== id));
      router.refresh();
    }
  };

  return (
    <div className="grid lg:grid-cols-[380px_1fr] gap-10">
      <form onSubmit={handleSubmit} className="space-y-3 lg:sticky lg:top-24 h-fit">
        <h2 className="font-display text-xl text-forest mb-2">
          {editingId ? "Edit product" : "Add a product"}
        </h2>
        <input
          required
          placeholder="Name"
          className="input"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <textarea
          required
          placeholder="Description"
          rows={3}
          className="input"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
        <div className="grid grid-cols-2 gap-3">
          <input
            required
            type="number"
            step="0.01"
            placeholder="Price (USD)"
            className="input"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })}
          />
          <input
            type="number"
            step="0.01"
            placeholder="Compare-at (optional)"
            className="input"
            value={form.compareAt}
            onChange={(e) => setForm({ ...form, compareAt: e.target.value })}
          />
        </div>
        <input
          required
          placeholder="Category"
          className="input"
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
        />
        <input
          required
          placeholder="Image URL"
          className="input"
          value={form.image_url}
          onChange={(e) => setForm({ ...form, image_url: e.target.value })}
        />
        <input
          required
          type="number"
          placeholder="Stock quantity"
          className="input"
          value={form.stock}
          onChange={(e) => setForm({ ...form, stock: e.target.value })}
        />
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) => setForm({ ...form, featured: e.target.checked })}
          />
          Feature on homepage
        </label>
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <div className="flex gap-3">
          <button type="submit" disabled={submitting} className="btn-primary flex-1">
            {submitting ? "Saving…" : editingId ? "Save changes" : "Add product"}
          </button>
          {editingId && (
            <button type="button" onClick={resetForm} className="btn-secondary">
              Cancel
            </button>
          )}
        </div>
      </form>

      <div>
        <h2 className="font-display text-xl text-forest mb-4">
          Catalog ({products.length})
        </h2>
        <ul className="divide-y divide-forest-100 border-y border-forest-100">
          {products.map((p) => (
            <li key={p.id} className="py-4 flex items-center gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={p.image_url}
                alt={p.name}
                className="w-14 h-16 object-cover rounded-sm bg-sand-100"
              />
              <div className="flex-1">
                <div className="font-medium">{p.name}</div>
                <div className="text-xs text-forest-400">
                  {p.category} · {formatPrice(p.price_cents)} · {p.stock} in stock
                  {p.featured ? " · Featured" : ""}
                </div>
              </div>
              <button onClick={() => startEdit(p)} className="text-sm text-brass-600 underline">
                Edit
              </button>
              <button
                onClick={() => handleDelete(p.id)}
                className="text-sm text-red-600 underline"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
