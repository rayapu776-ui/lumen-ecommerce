"use client";

import Link from "next/link";
import { useState } from "react";
import { useCart } from "./CartContext";

export function formatPrice(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

export default function ProductCard({ product }) {
  const { addItem } = useCart();
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);

  const handleAdd = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setAdding(true);
    await addItem(product.id, 1);
    setAdding(false);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <Link href={`/products/${product.id}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden bg-sand-100 rounded-sm">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {product.compare_at_cents && (
          <span className="absolute top-3 left-3 bg-brass text-white text-[10px] tracking-wide uppercase px-2 py-1 rounded-sm">
            Sale
          </span>
        )}
        <button
          onClick={handleAdd}
          disabled={adding}
          className="absolute bottom-3 right-3 bg-white/95 text-forest text-xs tracking-wide uppercase px-3 py-2 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-forest hover:text-white"
        >
          {added ? "Added ✓" : adding ? "Adding…" : "Quick add"}
        </button>
      </div>
      <div className="mt-3">
        <div className="text-xs text-forest-400">{product.category}</div>
        <div className="font-medium text-ink">{product.name}</div>
        <div className="mt-1 flex items-center gap-2">
          <span className="text-forest-600 font-medium">
            {formatPrice(product.price_cents)}
          </span>
          {product.compare_at_cents && (
            <span className="text-forest-400 line-through text-sm">
              {formatPrice(product.compare_at_cents)}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
