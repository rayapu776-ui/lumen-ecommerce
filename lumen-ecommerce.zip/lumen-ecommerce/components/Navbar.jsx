"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "./CartContext";

export default function Navbar({ user }) {
  const { count } = useCart();
  const router = useRouter();
  const [query, setQuery] = useState("");

  const handleSearch = (e) => {
    e.preventDefault();
    router.push(query ? `/products?q=${encodeURIComponent(query)}` : "/products");
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  return (
    <header className="sticky top-0 z-40 bg-sand-50/95 backdrop-blur border-b border-forest-100">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-center justify-between h-16 gap-6">
          <Link href="/" className="font-display text-2xl tracking-tight text-forest">
            LUMEN
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            <Link href="/products" className="hover:text-brass-600 transition-colors">
              Shop All
            </Link>
            <Link href="/products?category=Candles" className="hover:text-brass-600 transition-colors">
              Candles
            </Link>
            <Link href="/products?category=Ceramics" className="hover:text-brass-600 transition-colors">
              Ceramics
            </Link>
            <Link href="/products?category=Textiles" className="hover:text-brass-600 transition-colors">
              Textiles
            </Link>
          </nav>

          <form onSubmit={handleSearch} className="hidden sm:block flex-1 max-w-xs">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products…"
              className="w-full text-sm border border-forest-100 bg-white px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brass rounded-sm"
            />
          </form>

          <div className="flex items-center gap-4 text-sm">
            {user ? (
              <>
                <Link href="/account/orders" className="hover:text-brass-600 transition-colors">
                  {user.name.split(" ")[0]}
                </Link>
                {user.role === "admin" && (
                  <Link href="/admin/products" className="hover:text-brass-600 transition-colors">
                    Admin
                  </Link>
                )}
                <button onClick={handleLogout} className="hover:text-brass-600 transition-colors">
                  Log out
                </button>
              </>
            ) : (
              <Link href="/login" className="hover:text-brass-600 transition-colors">
                Log in
              </Link>
            )}
            <Link href="/cart" className="relative inline-flex items-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                <circle cx="9" cy="21" r="1" />
                <circle cx="20" cy="21" r="1" />
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
              </svg>
              {count > 0 && (
                <span className="absolute -top-2 -right-2 bg-brass text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                  {count}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
